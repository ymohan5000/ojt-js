// // // true && true     // true
// // // true && false    // false

// // // Example:
// // let age = 20;
// // if (age > 18 && age < 1) {
// //   console.log("You're a young adult.");  // ✅ Runs
// // }
// // else{
// //     console.log("you're a miner");
// // // }
// // false || true    // true
// // false || false   // false

// // Example:
// let user = "user";
// let name = user || "Guest";
// console.log(name); // "Guest"


console.log(2 ** 3); // 8 (2 to the power of 3)
console.log(5 ** 2); // 25 (5 squared)
console.log(4 ** 0.5); // 2 (square root of 4)