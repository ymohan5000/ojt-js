document.getElementById('h1');
console.log("hellow nepal ");