// //function declartion

// function ram(num){
//     return num*num
// }
// console.log(ram(10));


// //function expression
// const ram=function(num){
// return num*num
// }
// console.log(ram(22))


//arrow function
const ram=(nu)=>{
return nu*nu
}
console.log(ram(23))



setTimeout (function(){
    console.log("two second ")
},2000)