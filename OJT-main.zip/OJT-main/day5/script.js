let a=document.getElementById("ram");
console.log(a);
let b=document.getElementsByClassName("class")
console.log(b);
let c=document.getElementsByTagName("h1")
let first=document.querySelector('#ram')
console.log(first )

let h2=document.querySelector("h2")
console.log(h2.innerText);
h2.innerText=h2.innerText+"from nepal";
let div=document.querySelector("div")
console.log(div); 
let id=div.getAttribute("id")
console.log(id);
let name=div.getAttribute("name");
console.log(name)

