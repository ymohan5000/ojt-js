let div=document.getElementsByTagName("div");
console.dir(div)
let clas=document.getElementById("ramid")
console.log(clas);
let cla=document.getElementsByClassName("ram");
console.dir(cla)
document.querySelector("p");
