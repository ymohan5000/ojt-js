// function oddeven(number){
//     if(number%2===0){
//         return "Even";
//     }else
//     {

//         return "odd"
//     }
// }
// console.log(oddeven(2))
// console.log(oddeven(3))
// console.log(oddeven(2))
// console.log(oddeven(3))


// const oddevenarrow=(num)=>(num%2===0 ?"Even":"odd");

// console.log(oddevenarrow(2));
// console.log(oddevenarrow(9));
// console.log(oddevenarrow(6));

const oddevenexpression=function(number)
{
    if(number%2===0){
        return "Even"
    }
    {
        return "Odd"
    }
}
console.log(oddevenexpression(32));
console.log(oddevenexpression(31));
console.log(oddevenexpression(31));