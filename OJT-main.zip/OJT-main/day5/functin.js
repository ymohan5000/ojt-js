// function declaration
function geet(){
    console.log("the function is called")
};
geet();
// function expression
const geeta=function(){
    console.log("function exp is colled")
};
typeof geeta();
console.log(geeta());
geeta();







