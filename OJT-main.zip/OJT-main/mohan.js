
let x=5;
console.log(x);
let b=5;
console.log(b);