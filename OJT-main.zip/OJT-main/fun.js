function myFun(p1,p2)
{
    return p1*p2;
}
let x = myFun(4,3);
console.log(x); 