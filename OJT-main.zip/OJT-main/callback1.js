function ram(ram1,hari){
    console.log(ram1+"nepal")
    hari();
}
function ram11()
{
    console.log("jay shree ram");
}
ram("jay shree ramm",ram11)