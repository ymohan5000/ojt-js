{
    var x=100;
}
console.log(x)