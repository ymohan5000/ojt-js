let wether="";
if (wether==="rainy"){
    console.log("take an umbrella")
}
else if(wether==="gham"){
    console.log("take a black umberlla");
}
else{
    console.log("have a nice day")
}