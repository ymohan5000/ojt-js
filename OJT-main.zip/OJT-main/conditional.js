// if statement
if (condition) {
    // code to be executed if condition is true
}
// if-else statement
if (condition) {    
    // code to be executed if condition is true
}
else {
    // code to be executed if condition is false
}
// if-else if-else statement
if (condition1) {
    // code to be executed if condition1 is true
}   
else if (condition2) {
    // code to be executed if condition2 is true
}
else {
    // code to be executed if both condition1 and condition2 are false
}
// switch statement
switch (expression) {
    case value1:
        // code to be executed if expression equals value1
        break;
    case value2:
        // code to be executed if expression equals value2
        break;
    // you can have any number of case statements
    default:
        // code to be executed if expression doesn't match any case
        break;
}   
