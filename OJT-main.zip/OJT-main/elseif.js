let ageOfPerson=12;
if(ageOfPerson<=5){
    console.log("he/she is an infant should get a polio vaccine");

}
else if (ageOfPerson<5){
    console.log("he/she is an a toddler,should get a DTP vaccine");
    
}
else if(ageOfPerson<12){
    console.log("he is is a child, should get a MMR vaccine");

}
else if(ageOfPerson<18){
    console.log("he is a teenager should get a Tdap vaccine");
}
else{
    console.log("she is an adult,should get a flu  vaccine")
}