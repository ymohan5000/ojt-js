let age=10;
if (age>=18)
{
    console.log("your are adult");
}
else
{
    console.log("your are baby");
}
