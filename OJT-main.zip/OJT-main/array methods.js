// length method
// const fruits=["bana","orange","mango"];
// let size=fruits.length;
// console.log(size);
// console.log(fruits);

// //array push method
// fruits.push("mangoo2");
// console.log(fruits);
// fruits.pop();
// console.log(fruits);
// // arry shift
// const first=fruits.shift();
// console.log(first);
// // console.log(fruits);
// //arry unshift adds to start new array length
// const second=fruits.unshift("apple");
// console.log(second);
// console.log(fruits);

// //array of index of
// console.log(fruits.indexOf("apple"));
// console.log(fruits.indexOf("bana"));
// console.log(fruits.indexOf("mango"));
// console.log(fruits.indexOf("orange"));

//includes methods
const numbers = [1, 1, 2, 4, 5];

console.log(numbers.includes(5, 2)); // false (search starts at index 3)
console.log(numbers.includes(2, 2)); // true  (search starts at index 2)

// //sliced method
// const fruits=["apple","banana","cherry",'1','12','2'];
// const sliced=fruits.slice(1,4);
// console.log(sliced);
// console.log(fruits);

// //splice
// fruits.splice(1,2,"grape","kiwi")
// console.log(fruits);


//join methods
// const fruits=["applle","banana","cherry"];
// // const result=fruits.join();
// const joined=fruits.join();
// console.log(joined);

// //tostring
// const joined1=fruits.toString();
// console.log(joined1)

// const items = ["one", "two", "three"];

// console.log(items.toString());     // "one,two,three"
// console.log(items.join(" | "));   // "one | two | three"
