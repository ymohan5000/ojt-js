//7.	Create a function to reverse a string.
function ram(){
    return reversed;
}
console.log(ram("hello"));

