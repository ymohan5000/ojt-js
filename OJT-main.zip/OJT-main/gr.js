let number=85;
if(number<=90)
{
    console.log("your are first  devision pass");

}
else if(number<=60)
{
    console.log("your are second division pas")
}
else if(number<=35)
{
    console.log("your are just pass")
}
else 
{
    console.log("your are fail")
}