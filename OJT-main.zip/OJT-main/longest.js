function ram(a,b){
    if(a>b)
    {
        return a;
    }else{
        return b;
    }
}
console.log(ram(3,4));