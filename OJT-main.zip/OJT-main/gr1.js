let score=85;
if(score>=60){
    if (score >=90){
        console.log("Grade:A");
    }
    else{
        console.log("Grade :B");
    }}
    else
    {
        console.log("grade F")
    }
