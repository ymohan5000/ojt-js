let Number=[1,2,3,4,5,6];
Number.forEach((Number) => {
    console.log(Number);
});