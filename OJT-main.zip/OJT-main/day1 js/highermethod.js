//foreach method
const number=[8,5,3,4,4,8];
// number.forEach((num)=> {
//     console.log(num)
// });

// //map mathod
// const double=number.map((num)=>num*2);
// console.log(double)

//filter method
// const odd=number.filter((num)=>num%2!==0);
// const even=number.filter((num)=>num%2===0);
// console.log(odd);
// console.log(even);

//reduce mehtod
// const double=number.reduce((acc,num)=>num+acc,0)
// console.log(double)
//find method
// const double=number.find((num)=>num>3)
// console.log(double)

//some method
// const numb=[8,5,3,4,4,8];
// const double1=numb.some((num)=>num<0);
// console.log(double1)


//every method
// const double=number.every((num)=>num<18);
// console.log(double)

